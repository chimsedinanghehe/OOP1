public class SumofTwoDice {
    public static void main(String[] args) {
        int sides=6;
        int roll1= 1+(int) (Math.random() * sides);
        int roll2= 1+(int) (Math.random() * sides);
        int sum= roll1 + roll2;
        System.out.println(sum);
    }
}
