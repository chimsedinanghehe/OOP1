public class TenHellos {
    public static void main(String[] args) {
        System.out.println("1st Hello");
        System.out.println("2nd Hello");
        System.out.println("3rd Hello");

        for (int i=4 ;i<=10;i++)
        {
            System.out.println(i + "th Hello");
        }
    }
}
