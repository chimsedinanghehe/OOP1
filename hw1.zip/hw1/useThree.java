public class useThree {
    public static void main(String[] args) {

        String s1=args[0];
        String s2=args[1];
        String s3=args[2];

        System.out.println("hi " + s1 +"," + s2 + ", and " + s3);
    }
}
